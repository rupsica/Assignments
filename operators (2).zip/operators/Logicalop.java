public class LogicalCheck {
    public static void main(String[] args) {
        int num = 75;
        boolean result = (num >= 50 && num <= 100) && (num % 5 == 0);
        System.out.println("Is 75 between 50 and 100 and divisible by 5? " + result);
    }
}
