public class Addition {
    static int a = 10;
    static int b = 20;
    static int c = 30;

    public static void main(String[] args) {
        int sum = a + b + c;
        System.out.println("Sum = " + sum);
    }
}
