public class CompoundAssignment {
    public static void main(String[] args) {
        int n = 10;
        n += 2;  // 12
        n -= 3;  // 9
        n *= 2;  // 18
        n /= 3;  // 6
        n %= 4;  // 2
        System.out.println("Final value: " + n);
    }
}
