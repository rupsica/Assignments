public class BitwiseOps {
    public static void main(String[] args) {
        int x = 6, y = 3;
        System.out.println("AND: " + (x & y));
        System.out.println("OR : " + (x | y));
        System.out.println("XOR: " + (x ^ y));
    }
}
