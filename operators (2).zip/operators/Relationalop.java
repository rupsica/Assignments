public class RelationalCheck {
    public static void main(String[] args) {
        int number = 120;
        System.out.println("Is number > 100? " + (number > 100));
    }
}
