class Student {
       static String clgname = "Amrita University";

    String name = "Neha";
    String branch = "CSE";
    String location = "Benguluru";
    String initial = "G";
    String fatherName = "bullaiah";
    String motherName = "vijaya";
    int age = 22;
    String dob = "06-07-2003";

    public static void main(String[] args) {
                Student obj = new Student();

        System.out.print("Student Name ");
        System.out.println(obj.name);

        System.out.print("Initial ");
        System.out.println(obj.initial);

        System.out.print("College Name ");
        System.out.println(Student.clgname);

        System.out.print("Branch ");
        System.out.println(obj.branch);

        System.out.print("Location");
        System.out.println(obj.location);

        System.out.print("Father's Name ");
        System.out.println(obj.fatherName);

        System.out.print("Mother's Name ");
        System.out.println(obj.motherName);

        System.out.print("Age ");
        System.out.println(obj.age);

        System.out.print("Date of Birth ");
        System.out.println(obj.dob);
    }
}
