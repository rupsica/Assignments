public class LargestNumber {
    static int a = 40;
    static int b = 60;
    static int c = 50;

    public static void main(String[] args) {
        int largest = (a > b && a > c) ? a : (b > c ? b : c);
        System.out.println("Largest number is: " + largest);
    }
}
