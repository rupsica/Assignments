public class AreaPerimeter {
    public static void main(String[] args) {
        int length = 10, width = 5;
        int area = length * width;
        int perimeter = 2 * (length + width);
        System.out.println("Area: " + area);
        System.out.println("Perimeter: " + perimeter);
    }
}
