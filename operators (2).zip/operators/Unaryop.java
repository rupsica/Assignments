public class Countdown {
    public static void main(String[] args) {
        int timer = 3;
        System.out.println(timer--);
        System.out.println(timer--);
        System.out.println(timer--);
    }
}
