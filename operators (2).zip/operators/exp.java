public class ExpressionCalculation {
    static int a = 5;
    static int b = 3;
    static int c = 2;

    public static void main(String[] args) {
        int result = (a + b) * c;
        System.out.println("Result = " + result);
    }
}
