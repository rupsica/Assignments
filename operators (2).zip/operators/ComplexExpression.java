public class ComplexExpression {
    public static void main(String[] args) {
        int result = 10 + 3 * 2 - 5 / 5 + 6 % 4;
        System.out.println("Result: " + result); // 10 + 6 - 1 + 2 = 17
    }
}
