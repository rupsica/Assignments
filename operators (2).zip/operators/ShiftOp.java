public class ShiftOps {
    public static void main(String[] args) {
        int value = 8;
        System.out.println("Left Shift (×2): " + (value << 1));
        System.out.println("Right Shift (÷2): " + (value >> 1));
    }
}
