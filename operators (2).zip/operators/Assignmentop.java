public class SalaryUpdate {
    public static void main(String[] args) {
        int salary = 10000;
        salary += salary * 0.2;
        System.out.println("Updated Salary: " + salary);
    }
}
