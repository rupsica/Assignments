class College {
        static String collegeName = "amrita";
    static String noOfBranches = "cse";
    static int noOfEmployees = 10;
    static int classroomNumber = 3;

       String studentName = "neha";
    String classLeader = "ajay";

    public static void main(String[] args) {
                College obj = new College();

                System.out.print("College Name ");
        System.out.println(College.collegeName);

        System.out.print("Number of Branches ");
        System.out.println(College.noOfBranches);

        System.out.print("Number of Employees ");
        System.out.println(College.noOfEmployees);

        System.out.print("Classroom Number ");
        System.out.println(College.classroomNumber);
        System.out.print("Student Name ");
        System.out.println(obj.studentName);

        System.out.print("Class Leader ");
        System.out.println(obj.classLeader);
    }
}

